# MT5-MQL5-MACD-Classic
A "classic" non-native version of the MACD Indicator for Meta Trader 5, written in MQL5

## Installation & Usage

Everything you would need to know about this indicator is covered in this blog post:  [https://base34.com/classic-macd-indicator-for-mt5/](https://base34.com/classic-macd-indicator-for-mt5/)
